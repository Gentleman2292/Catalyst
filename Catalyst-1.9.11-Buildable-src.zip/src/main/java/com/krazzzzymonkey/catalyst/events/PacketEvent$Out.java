/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.events;

import net.minecraft.network.Packet;

public class PacketEvent$Out extends PacketEvent
{
    public PacketEvent$Out(final Packet packet) {
        super(packet);
    }
}
