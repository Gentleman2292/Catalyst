/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils;

public class GeometryMasks$Line
{
    public static int SOUTH_EAST;
    public static int DOWN_SOUTH;
    public static int UP_NORTH;
    public static int UP_SOUTH;
    public static int ALL;
    public static int DOWN_NORTH;
    public static int NORTH_EAST;
    public static int DOWN_WEST;
    public static int UP_EAST;
    public static int NORTH_WEST;
    public static int SOUTH_WEST;
    public static int UP_WEST;
    public static int DOWN_EAST;
    
    static {
        GeometryMasks$Line.UP_SOUTH = 10;
        GeometryMasks$Line.DOWN_WEST = 17;
        GeometryMasks$Line.UP_EAST = 34;
        GeometryMasks$Line.DOWN_EAST = 33;
        GeometryMasks$Line.NORTH_EAST = 36;
        GeometryMasks$Line.NORTH_WEST = 20;
        GeometryMasks$Line.SOUTH_EAST = 40;
        GeometryMasks$Line.SOUTH_WEST = 24;
        GeometryMasks$Line.UP_NORTH = 6;
        GeometryMasks$Line.ALL = 63;
        GeometryMasks$Line.DOWN_SOUTH = 9;
        GeometryMasks$Line.DOWN_NORTH = 5;
        GeometryMasks$Line.UP_WEST = 18;
    }
}
