/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils;

public class LogOutSpot
{
    public double y;
    public double z;
    public String name;
    public double x;
    
    public LogOutSpot(final double x, final double y, final double z, final String name) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.name = name;
    }
}
