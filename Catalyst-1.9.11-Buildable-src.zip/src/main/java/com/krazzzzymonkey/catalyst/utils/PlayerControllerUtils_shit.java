package com.krazzzzymonkey.catalyst.utils;

import com.krazzzzymonkey.catalyst.utils.system.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;

public class PlayerControllerUtils_shit
extends PlayerControllerMP {
    public float range = (float) Wrapper.INSTANCE.player().getEntityAttribute(EntityPlayer.REACH_DISTANCE).getAttributeValue();

    public float getBlockReachDistance() {
        return this.range;
    }

    public void setBlockReachDistance(float f) {
        this.range = f;
    }

    public PlayerControllerUtils_shit(Minecraft minecraft, NetHandlerPlayClient netHandlerPlayClient) {
        super(minecraft, netHandlerPlayClient);
    }
}