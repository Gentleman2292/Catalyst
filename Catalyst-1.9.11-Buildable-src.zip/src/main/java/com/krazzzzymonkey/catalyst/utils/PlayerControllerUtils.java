/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils;

import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.client.Minecraft;
import java.lang.reflect.Field;
import com.krazzzzymonkey.catalyst.utils.system.Mapping;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import com.krazzzzymonkey.catalyst.utils.system.Wrapper;
import net.minecraft.entity.Entity;
import net.minecraft.world.GameType;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

public class PlayerControllerUtils
{
    public static void setReach(final Entity entity, final double d) {
        block1: {
            Minecraft minecraft = Wrapper.INSTANCE.mc();
            EntityPlayerSP entityPlayerSP = Wrapper.INSTANCE.player();
            if (entityPlayerSP != entity) break block1;
            if (!(minecraft.playerController instanceof PlayerControllerUtils_shit)) {
                GameType gameType = (GameType) ReflectionHelper.getPrivateValue(PlayerControllerMP.class, minecraft.playerController, Mapping.currentGameType);//(PlayerControllerMP.class, (Object)minecraft.playerController, (String[])new String[]{Mapping.currentGameType});
                NetHandlerPlayClient netHandlerPlayClient = (NetHandlerPlayClient)ReflectionHelper.getPrivateValue(PlayerControllerMP.class, minecraft.playerController, (String[])new String[]{Mapping.connection});
                PlayerControllerUtils_shit playerControllerUtils$1RangePlayerController = new PlayerControllerUtils_shit(minecraft, netHandlerPlayClient);
                boolean bl = entityPlayerSP.capabilities.isFlying;
                boolean bl2 = entityPlayerSP.capabilities.allowFlying;
                playerControllerUtils$1RangePlayerController.setGameType(gameType);
                entityPlayerSP.capabilities.isFlying = bl;
                entityPlayerSP.capabilities.allowFlying = bl2;
                minecraft.playerController = playerControllerUtils$1RangePlayerController;
            }
            ((PlayerControllerUtils_shit)minecraft.playerController).setBlockReachDistance((float)d);
        }
    }
    
    public static void setBlockHitDelay(final int i) {
        try {
            final Field declaredField = PlayerControllerMP.class.getDeclaredField(Mapping.blockHitDelay);
            declaredField.setAccessible(true);
            declaredField.setInt(Wrapper.INSTANCE.mc().playerController, i);
        }
        catch (Exception ex) {}
    }
    
    public static void setIsHittingBlock(final boolean z) {
        try {
            final Field declaredField = PlayerControllerMP.class.getDeclaredField(Mapping.isHittingBlock);
            declaredField.setAccessible(true);
            declaredField.setBoolean(Wrapper.INSTANCE.mc().playerController, z);
        }
        catch (Exception ex) {}
    }
    
    public static int findObiInHotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stackInSlot = Minecraft.getMinecraft().player.inventory.getStackInSlot(i);
            if (stackInSlot != ItemStack.EMPTY && stackInSlot.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stackInSlot.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public static float getCurBlockDamageMP() {
        float float1 = 0.0f;
        try {
            final Field declaredField = PlayerControllerMP.class.getDeclaredField(Mapping.curBlockDamageMP);
            declaredField.setAccessible(true);
            float1 = declaredField.getFloat(Wrapper.INSTANCE.mc().playerController);
        }
        catch (Exception ex) {}
        return float1;
    }
}
