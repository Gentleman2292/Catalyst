/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils;

public class GeometryMasks$Quad
{
    public static int ALL;
    public static int SOUTH;
    public static int EAST;
    public static int NORTH;
    public static int WEST;
    public static int UP;
    public static int DOWN;
    
    static {
        GeometryMasks$Quad.UP = 2;
        GeometryMasks$Quad.ALL = 63;
        GeometryMasks$Quad.SOUTH = 8;
        GeometryMasks$Quad.WEST = 16;
        GeometryMasks$Quad.NORTH = 4;
        GeometryMasks$Quad.EAST = 32;
        GeometryMasks$Quad.DOWN = 1;
    }
}
