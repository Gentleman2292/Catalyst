/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils.paste;

public class PasteBuilder$PasteFile$PasteContent
{
    public String format;
    public String value;
    
    public PasteBuilder$PasteFile$PasteContent(final String s, final PasteBuilder$1 pasteBuilder$1) {
        this(s);
    }
    
    public PasteBuilder$PasteFile$PasteContent(final String value) {
        this.format = "text";
        this.format = "text";
        this.value = value;
    }
}
