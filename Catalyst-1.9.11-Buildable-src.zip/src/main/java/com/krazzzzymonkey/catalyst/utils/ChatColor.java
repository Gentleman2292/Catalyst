// Decompiled with: CFR 0.152
// Class Version: 8
package com.krazzzzymonkey.catalyst.utils;

import java.util.regex.Pattern;

public class ChatColor {
    public static ChatColor MAGIC;
    public static char COLOR_CHAR;
    public static ChatColor DARK_GRAY;
    public static ChatColor STRIKETHROUGH;
    public static ChatColor DARK_AQUA;
    public static ChatColor DARK_GREEN;
    public boolean isFormat;
    public static ChatColor DARK_RED;
    public static ChatColor GRAY;
    public static ChatColor BOLD;
    public static ChatColor LIGHT_PURPLE;
    public static ChatColor DARK_BLUE;
    public static ChatColor RESET;
    public static ChatColor WHITE;
    public char code;
    public static ChatColor YELLOW;
    public static ChatColor ITALIC;
    public static ChatColor BLUE;
    public static ChatColor[] $VALUES;
    public static ChatColor DARK_PURPLE;
    public static ChatColor GOLD;
    public static ChatColor GREEN;
    public String toString;
    public static ChatColor BLACK;
    public static ChatColor UNDERLINE;
    public static ChatColor AQUA;
    public static ChatColor RED;

    public boolean isFormat() {
        return this.isFormat;
    }

    static {
        COLOR_CHAR = (char)167;
        BLACK = new ChatColor("BLACK", 0, '0');
        DARK_BLUE = new ChatColor("DARK_BLUE", 1, '1');
        DARK_GREEN = new ChatColor("DARK_GREEN", 2, '2');
        DARK_AQUA = new ChatColor("DARK_AQUA", 3, '3');
        DARK_RED = new ChatColor("DARK_RED", 4, '4');
        DARK_PURPLE = new ChatColor("DARK_PURPLE", 5, '5');
        GOLD = new ChatColor("GOLD", 6, '6');
        GRAY = new ChatColor("GRAY", 7, '7');
        DARK_GRAY = new ChatColor("DARK_GRAY", 8, '8');
        BLUE = new ChatColor("BLUE", 9, '9');
        GREEN = new ChatColor("GREEN", 10, 'a');
        AQUA = new ChatColor("AQUA", 11, 'b');
        RED = new ChatColor("RED", 12, 'c');
        LIGHT_PURPLE = new ChatColor("LIGHT_PURPLE", 13, 'd');
        YELLOW = new ChatColor("YELLOW", 14, 'e');
        WHITE = new ChatColor("WHITE", 15, 'f');
        MAGIC = new ChatColor("MAGIC", 16, 'k', true);
        BOLD = new ChatColor("BOLD", 17, 'l', true);
        STRIKETHROUGH = new ChatColor("STRIKETHROUGH", 18, 'm', true);
        UNDERLINE = new ChatColor("UNDERLINE", 19, 'n', true);
        ITALIC = new ChatColor("ITALIC", 20, 'o', true);
        RESET = new ChatColor("RESET", 21, 'r');
        $VALUES = new ChatColor[]{BLACK, DARK_BLUE, DARK_GREEN, DARK_AQUA, DARK_RED, DARK_PURPLE, GOLD, GRAY, DARK_GRAY, BLUE, GREEN, AQUA, RED, LIGHT_PURPLE, YELLOW, WHITE, MAGIC, BOLD, STRIKETHROUGH, UNDERLINE, ITALIC, RESET};
    }

    /*
     * WARNING - void declaration
     */
    public ChatColor(String v1, int v2, char v3, boolean v4) {
        this.code = v3;
        this.isFormat = v4;
        this.toString = new String(new char[]{'§', v3});
    }

    public char getChar() {
        return this.code;
    }

    public boolean isColor() {
        return !this.isFormat && this != RESET;
    }

    public static ChatColor[] values() {
        return (ChatColor[])$VALUES.clone();
    }

    public static String stripColor(String string) {
        return string == null ? null : Pattern.compile("(?i)§[0-9A-FK-OR]").matcher(string).replaceAll("");
    }

    public String toString() {
        return this.toString;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    public ChatColor(String v1, int v2, char v3) {
        this((String)v1, (int)v2, (char)v3, false);
    }

    public static String translateAlternateColorCodes(char c, String string) {
        char[] cArray = string.toCharArray();
        int n = cArray.length - 1;
        for (int i = 0; i < n; ++i) {
            if (cArray[i] != c || "0123456789AaBbCcDdEeFfKkLlMmNnOoRr".indexOf(cArray[i + 1]) <= -1) continue;
            cArray[i] = 167;
            cArray[i + 1] = Character.toLowerCase(cArray[i + 1]);
        }
        return new String(cArray);
    }
}
