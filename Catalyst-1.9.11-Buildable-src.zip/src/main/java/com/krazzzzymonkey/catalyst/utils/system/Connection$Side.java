// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.utils.system;

public enum Connection$Side {
    IN,
    OUT;

}
