/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.utils.font;

public class CFont$CharData
{
    public int storedX;
    public CFont this$0;
    public int height;
    public int storedY;
    public int width;
    
    public CFont$CharData(final CFont this$0) {
        this.this$0 = this$0;
    }
}
