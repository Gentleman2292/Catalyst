/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.configuration;

public class Alignment
{
    public float factorY;
    public float factorX;
    
    public Alignment(final float factorX, final float factorY) {
        this.factorX = factorX;
        this.factorY = factorY;
    }
}
