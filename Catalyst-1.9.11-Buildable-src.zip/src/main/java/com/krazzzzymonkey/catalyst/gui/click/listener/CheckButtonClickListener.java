/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.elements.CheckButton;

public interface CheckButtonClickListener
{
    void onCheckButtonClick(final CheckButton p0);
}
