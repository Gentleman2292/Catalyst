/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.gui;

import com.krazzzzymonkey.catalyst.lib.ANCHOR;

public class GuiCustomLabel$1
{
    public static int[] $SwitchMap$com$krazzzzymonkey$catalyst$lib$ANCHOR;
    
    static {
        GuiCustomLabel$1.$SwitchMap$com$krazzzzymonkey$catalyst$lib$ANCHOR = new int[ANCHOR.values().length];
        try {
            GuiCustomLabel$1.$SwitchMap$com$krazzzzymonkey$catalyst$lib$ANCHOR[ANCHOR.END.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            GuiCustomLabel$1.$SwitchMap$com$krazzzzymonkey$catalyst$lib$ANCHOR[ANCHOR.MIDDLE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            GuiCustomLabel$1.$SwitchMap$com$krazzzzymonkey$catalyst$lib$ANCHOR[ANCHOR.START.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
    }
}
