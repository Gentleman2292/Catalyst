/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.gui.click.listener;

import com.krazzzzymonkey.catalyst.gui.click.elements.ComboBox;

public interface ComboBoxListener
{
    void onComboBoxSelectionChange(final ComboBox p0);
}
