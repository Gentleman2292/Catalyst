// Decompiled with: CFR 0.152
// Class Version: 8
package com.krazzzzymonkey.catalyst.gui.click.base;

public enum ComponentType {
    FRAME,
    PANEL,
    BUTTON,
    EXPANDING_BUTTON,
    CHECK_BUTTON,
    SLIDER,
    KEYBIND,
    TEXT,
    DROPDOWN,
    COMBO_BOX,
    COLOR_PICKER;

}
