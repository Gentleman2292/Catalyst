/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.value;

public class Value
{
    public Object defaultValue;
    public Object value;
    public String name;
    
    public void setValue(final Object value) {
        this.value = value;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Object getValue() {
        return this.value;
    }
    
    public Object getDefaultValue() {
        return this.defaultValue;
    }
    
    public Value(final String name, final Object o) {
        this.name = name;
        this.defaultValue = o;
        this.value = o;
    }
}
