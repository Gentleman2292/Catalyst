/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.value.types;

import com.krazzzzymonkey.catalyst.value.Value;

public class BooleanValue extends Value
{
    public BooleanValue(final String s, final boolean b) {
        super(s, b);
    }

    @Override
    public Boolean getValue()
    {
        return ((Boolean)super.getValue());
    }
}
