/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.value.types;

import com.krazzzzymonkey.catalyst.value.Value;

public class Number extends Value
{
    public Double min;
    public Double max;
    
    public Number(final String s, final Integer n) {
        super(s, n);
    }
}
