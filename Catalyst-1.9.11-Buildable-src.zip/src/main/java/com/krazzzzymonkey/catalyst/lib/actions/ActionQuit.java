/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.lib.actions;

import com.krazzzzymonkey.catalyst.gui.GuiCustom;

public class ActionQuit implements IAction
{
    @Override
    public void perform(final Object source, final GuiCustom menu) {
        menu.mc.shutdown();
    }
}
