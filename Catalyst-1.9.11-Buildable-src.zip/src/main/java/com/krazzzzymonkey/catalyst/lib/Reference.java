/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.lib;

public class Reference
{
    public static final String OPEN_EYE_MODID = "OpenEye";
    public static final int OPEN_EYE_BUTTON = 666;
    public static final String VERSION_CHECKER_MODID = "VersionChecker";
    public static final int VERSION_CHECKER_BUTTON = 404;
}
