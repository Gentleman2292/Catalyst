/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.render;

import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.Mode;
import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import com.krazzzzymonkey.catalyst.value.types.ModeValue;
import net.minecraft.client.Minecraft;
import com.krazzzzymonkey.catalyst.module.Modules;

public class NetherSky extends Modules
{
    public static Minecraft mc;
    public static NetherSky$ISpaceRenderer skyboxSpaceRenderer;
    public ModeValue mode;
    public boolean wasChanged;
    
    public void enableBackgroundRenderer(final World world) {
        block0: {
            if (world.provider.getDimensionType() != DimensionType.NETHER) break block0;
            world.provider.setSkyRenderer((IRenderHandler)new NetherSky_Render(this));
        }
    }
    
    @SubscribeEvent
    public void onWorldLoad(final WorldEvent.Load worldEvent$Load) {
        this.wasChanged = false;
    }
    
    @SubscribeEvent
    public void onWorldUnload(final WorldEvent.Unload worldEvent$Unload) {
        this.wasChanged = false;
    }
    
    @SubscribeEvent
    public void onClientTick(final TickEvent.ClientTickEvent tickEvent$ClientTickEvent) {
        if (Minecraft.getMinecraft().world == null || Minecraft.getMinecraft().player == null || Minecraft.getMinecraft().player.getUniqueID() == null) {
            return;
        }
        if (this.wasChanged) {
            return;
        }
        this.enableBackgroundRenderer(NetherSky.mc.player.world);
        this.wasChanged = true;
    }
    
    @Override
    public void onDisable() {
        this.disableBackgroundRenderer(NetherSky.mc.player.world);
        super.onDisable();
    }
    
    public NetherSky() {
        super("NetherSky", ModuleCategory.RENDER, "Nether Sky");
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("Dickbutt", true), new Mode("Cow", false), new Mode("Grin", false), new Mode("0b0t", false), new Mode("Arthur", false), new Mode("Impact", false) });
        this.addValue(this.mode);
        NetherSky.skyboxSpaceRenderer = new NetherSky$SkyboxSpaceRenderer(NetherSky.mc);
    }
    
    public void disableBackgroundRenderer(final World world) {
        block0: {
            if (world.provider.getDimensionType() != DimensionType.NETHER) break block0;
            world.provider.setSkyRenderer((IRenderHandler)new NetherSky_NoRender(this));
        }
    }
    
    public static NetherSky$ISpaceRenderer access$100() {
        return NetherSky.skyboxSpaceRenderer;
    }
    
    static {
        NetherSky.mc = Minecraft.getMinecraft();
    }
    
    @Override
    public void onEnable() {
        this.wasChanged = false;
        super.onEnable();
    }
    
    public static ModeValue access$000(final NetherSky netherSky) {
        return netherSky.mode;
    }
}
