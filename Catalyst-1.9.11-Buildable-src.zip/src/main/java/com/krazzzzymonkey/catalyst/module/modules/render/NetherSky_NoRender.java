package com.krazzzzymonkey.catalyst.module.modules.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraftforge.client.IRenderHandler;

public class NetherSky_NoRender
extends IRenderHandler {
    public NetherSky this$0;

    public NetherSky_NoRender(NetherSky netherSky) {
        this.this$0 = netherSky;
    }

    public void render(float f, WorldClient worldClient, Minecraft minecraft) {
    }
}
