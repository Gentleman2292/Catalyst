package com.krazzzzymonkey.catalyst.module.modules.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraftforge.client.IRenderHandler;

public class NetherSky_Render
extends IRenderHandler {
    public NetherSky this$0;

    public void render(float f, WorldClient worldClient, Minecraft minecraft) {
        NetherSky.access$100().render(NetherSky.access$000(this.this$0));
    }

    public NetherSky_Render(NetherSky netherSky) {
        this.this$0 = netherSky;
    }
}
