// Decompiled with: CFR 0.152
// Class Version: 8
package com.krazzzzymonkey.catalyst.module;

public enum ModuleCategory {
    CHAT,
    COMBAT,
    GUI,
    MISC,
    MOVEMENT,
    PLAYER,
    RENDER,
    WORLD,
    HUD;

}
