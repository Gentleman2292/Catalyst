// Decompiled with: CFR 0.152
// Class Version: 8
package com.krazzzzymonkey.catalyst.module.modules;

public enum HudCategory {
    HUD;

}
