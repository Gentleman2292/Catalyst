/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.combat;

public class ObsidianReplace$HandSwapContext
{
    public int oldSlot;
    public int newSlot;
    
    public int getOldSlot() {
        return this.oldSlot;
    }
    
    public ObsidianReplace$HandSwapContext(final int oldSlot, final int newSlot) {
        this.oldSlot = oldSlot;
        this.newSlot = newSlot;
    }
    
    public int getNewSlot() {
        return this.newSlot;
    }
}
