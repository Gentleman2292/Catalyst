/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.chat;

import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;

public class ToggleMessages extends Modules
{
    public ToggleMessages() {
        super("ToggleMessages", ModuleCategory.CHAT, "Sends a clientside message when you toggle a module");
    }
}
