/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.world;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.block.Block;
import net.minecraft.util.math.Vec3i;

import java.util.stream.Stream;
import net.minecraft.util.math.Vec3d;
import com.krazzzzymonkey.catalyst.utils.PlayerControllerUtils;

import java.util.HashSet;
import com.krazzzzymonkey.catalyst.utils.system.Wrapper;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;
import java.util.stream.StreamSupport;
import com.krazzzzymonkey.catalyst.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import com.krazzzzymonkey.catalyst.utils.visual.RenderUtils;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.krazzzzymonkey.catalyst.utils.BlockUtils;
import com.krazzzzymonkey.catalyst.value.Mode;
import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.value.sliders.DoubleValue;
import java.util.Set;
import java.util.ArrayDeque;
import net.minecraft.util.math.BlockPos;
import com.krazzzzymonkey.catalyst.value.types.ModeValue;
import com.krazzzzymonkey.catalyst.module.Modules;

public class Nuker extends Modules
{
    public ModeValue mode;
    public float prevProgress;
    public BlockPos currentBlock;
    public float progress;
    public ArrayDeque<Set<BlockPos>> prevBlocks;
    public DoubleValue distance;
    public int id;
    
    public Nuker() {
        super("Nuker", ModuleCategory.WORLD, "Automatically breaks specified blocks in players reach");
        this.prevBlocks = new ArrayDeque<Set<BlockPos>>();
        this.mode = new ModeValue("Mode", new Mode[] { new Mode("ID", true), new Mode("All", false) });
        this.distance = new DoubleValue("Distance", 6.0, 0.1, 6.0);
        this.addValue(this.mode, this.distance);
    }
    
    public static boolean lambda$onClientTick$1(final BlockPos blockPos) {
        return BlockUtils.canBeClicked(blockPos);
    }
    
    @SubscribeEvent
    public void onRenderWorldLast(final RenderWorldLastEvent renderWorldLastEvent) {
        if (this.currentBlock == null) {
            return;
        }
        if (this.mode.getMode("All").isToggled()) {
            RenderUtils.drawBlockESP(this.currentBlock, 1.0f, 0.0f, 0.0f, 1.0);
        }
        else if (this.mode.getMode("ID").isToggled()) {
            RenderUtils.drawBlockESP(this.currentBlock, 0.0f, 0.0f, 1.0f, 1.0);
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent clientTickEvent) {
        block16: {
            block15: {
                if (Minecraft.getMinecraft().world == null || Minecraft.getMinecraft().player == null) break block15;
                if (Minecraft.getMinecraft().player.getUniqueID() != null) break block16;
            }
            return;
        }
        this.currentBlock = null;
        Vec3d vec3d = Utils.getEyesPos().subtract(0.5, 0.5, 0.5);
        BlockPos blockPos = new BlockPos(Utils.getEyesPos());
        double d = Math.pow(this.distance.getValue(), 2.0);
        int n = (int)Math.ceil(this.distance.getValue());
        Stream<BlockPos> stream = StreamSupport.stream(BlockPos.getAllInBox((BlockPos)blockPos.add(n, n, n), (BlockPos)blockPos.add(-n, -n, -n)).spliterator(), true);
        stream = stream.filter(arg_0 -> Nuker.soy(vec3d, d, arg_0)).filter(Nuker::lambda$onClientTick$1).sorted(Comparator.comparingDouble(arg_0 -> Nuker.lambda$onClientTick$2(vec3d, arg_0)));
        if (this.mode.getMode("ID").isToggled()) {
            stream = stream.filter(this::lambda$onClientTick$3);
        } else if (this.mode.getMode("All").isToggled()) {
            // empty if block
        }
        List<BlockPos> list = stream.collect(Collectors.toList());
        if (Wrapper.INSTANCE.player().capabilities.isCreativeMode) {
            Stream<BlockPos> stream2 = list.parallelStream();
            for (Set<BlockPos> set : this.prevBlocks) {
                stream2 = stream2.filter(arg_0 -> Nuker.lambda$onClientTick$4(set, arg_0));
            }
            List list2 = stream2.collect(Collectors.toList());
            this.prevBlocks.addLast(new HashSet(list2));
            while (this.prevBlocks.size() > 5) {
                this.prevBlocks.removeFirst();
            }
            if (!list2.isEmpty()) {
                this.currentBlock = (BlockPos)list2.get(0);
            }
            Wrapper.INSTANCE.mc().playerController.resetBlockRemoving();
            this.progress = 1.0f;
            this.prevProgress = 1.0f;
            BlockUtils.breakBlocksPacketSpam(list2);
            return;
        }
        for (BlockPos blockPos2 : list) {
            if (!BlockUtils.breakBlockSimple(blockPos2)) continue;
            this.currentBlock = blockPos2;
            break;
        }
        if (this.currentBlock == null) {
            Wrapper.INSTANCE.mc().playerController.resetBlockRemoving();
        }
        if (this.currentBlock != null && BlockUtils.getHardness(this.currentBlock) < 1.0f) {
            this.prevProgress = this.progress;
        }
        this.progress = PlayerControllerUtils.getCurBlockDamageMP();
        if (this.progress < this.prevProgress) {
            this.prevProgress = this.progress;
        } else {
            this.progress = 1.0f;
            this.prevProgress = 1.0f;
        }
    }
    
    public static double lambda$onClientTick$2(final Vec3d vec3d, final BlockPos blockPos) {
        return vec3d.squareDistanceTo(new Vec3d((Vec3i)blockPos));
    }
    
    @Override
    public void onDisable() {
        if (this.currentBlock != null) {
            PlayerControllerUtils.setIsHittingBlock(true);
            Wrapper.INSTANCE.mc().playerController.resetBlockRemoving();
            this.currentBlock = null;
        }
        this.prevBlocks.clear();
        this.id = 0;
        super.onDisable();
    }
    
    public boolean lambda$onClientTick$3(final BlockPos blockPos) {
        return Block.getIdFromBlock(Wrapper.INSTANCE.world().getBlockState(blockPos).getBlock()) == this.id;
    }
    
    @SubscribeEvent
    public void onLeftClickBlock(final PlayerInteractEvent.LeftClickBlock playerInteractEvent$LeftClickBlock) {
        if (this.mode.getMode("ID").isToggled() && Wrapper.INSTANCE.world().isRemote) {
            this.id = Block.getIdFromBlock(Wrapper.INSTANCE.world().getBlockState(playerInteractEvent$LeftClickBlock.getPos()).getBlock());
        }
    }
    
    public static boolean soy(final Vec3d vec3d, final double n, final BlockPos blockPos) {
        return vec3d.squareDistanceTo(new Vec3d((Vec3i)blockPos)) <= n;
    }
    
    public static boolean lambda$onClientTick$4(final Set set, final BlockPos blockPos) {
        return !set.contains(blockPos);
    }
}
