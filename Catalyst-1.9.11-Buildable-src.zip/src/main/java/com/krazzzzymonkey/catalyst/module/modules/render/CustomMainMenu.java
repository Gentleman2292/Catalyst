/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.render;

import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;

public class CustomMainMenu extends Modules
{
    public CustomMainMenu() {
        super("CustomMainMenu", ModuleCategory.RENDER, "Toggles Catalyst Main Menu");
    }
}
