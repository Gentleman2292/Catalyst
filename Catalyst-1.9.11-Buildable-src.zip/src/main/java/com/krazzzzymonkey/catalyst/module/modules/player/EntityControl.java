/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.module.modules.player;

import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;

public class EntityControl extends Modules
{
    public EntityControl() {
        super("EntityControl", ModuleCategory.MOVEMENT, "Allows you to ride entities without saddles or taming them.");
    }
}
