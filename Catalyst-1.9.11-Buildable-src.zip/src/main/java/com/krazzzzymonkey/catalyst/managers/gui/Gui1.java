package com.krazzzzymonkey.catalyst.managers.gui;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.elements.ExpandingButton;
import com.krazzzzymonkey.catalyst.managers.GuiManager;
import com.krazzzzymonkey.catalyst.module.Modules;

public class Gui1
extends ExpandingButton {
    public GuiManager this$0;
    public Modules val$mod;

    @Override
    public void onUpdate() {
        this.setEnabled(this.val$mod.isToggled());
    }

    public Gui1(GuiManager guiManager, int n, int n2, int n3, int n4, Component component, String string, Modules modules, Modules modules2) {
        super(n, n2, n3, n4, component, string, modules);
        this.this$0 = guiManager;
        this.val$mod = modules2;
    }
}
