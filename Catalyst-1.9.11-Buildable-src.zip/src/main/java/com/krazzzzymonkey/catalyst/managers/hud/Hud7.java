// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.elements.ColorPicker;
import com.krazzzzymonkey.catalyst.gui.click.listener.ColorChangeListener;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.types.ColorValue;

public class Hud7
        implements ColorChangeListener {
    public HudEditorManager this$0;
    public Value val$value;

    @Override
    public void onColorChangeClick(ColorPicker colorPicker) {
        ((ColorValue)this.val$value).setColor(colorPicker.getColor());
    }

    public Hud7(HudEditorManager hudEditorManager, Value value) {
        this.this$0 = hudEditorManager;
        this.val$value = value;
    }
}
