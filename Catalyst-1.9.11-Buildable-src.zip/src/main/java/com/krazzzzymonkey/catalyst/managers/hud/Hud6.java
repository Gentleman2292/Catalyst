// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.elements.CheckButton;
import com.krazzzzymonkey.catalyst.gui.click.listener.CheckButtonClickListener;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.value.Mode;
import com.krazzzzymonkey.catalyst.value.types.ModeValue;

public class Hud6
        implements CheckButtonClickListener {
    public ModeValue val$modeValue;
    public Mode val$mode;
    public HudEditorManager this$0;

    @Override
    public void onCheckButtonClick(CheckButton checkButton) {
        for (Mode mode : this.val$modeValue.getModes()) {
            if (!mode.getName().equals(this.val$mode.getName())) continue;
            mode.setToggled(checkButton.isEnabled());
        }
    }

    public Hud6(HudEditorManager hudEditorManager, ModeValue modeValue, Mode mode) {
        this.this$0 = hudEditorManager;
        this.val$modeValue = modeValue;
        this.val$mode = mode;
    }
}
