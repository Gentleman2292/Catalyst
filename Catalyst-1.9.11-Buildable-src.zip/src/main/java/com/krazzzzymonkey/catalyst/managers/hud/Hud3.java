// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.elements.CheckButton;
import com.krazzzzymonkey.catalyst.gui.click.listener.CheckButtonClickListener;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.types.BooleanValue;

public class Hud3
        implements CheckButtonClickListener {
    public BooleanValue val$booleanValue;
    public Modules val$mod;
    public HudEditorManager this$0;

    @Override
    public void onCheckButtonClick(CheckButton checkButton) {
        for (Value value : this.val$mod.getValues()) {
            if (!value.getName().equals(this.val$booleanValue.getName())) continue;
            value.setValue(checkButton.isEnabled());
        }
    }

    public Hud3(HudEditorManager hudEditorManager, Modules modules, BooleanValue booleanValue) {
        this.this$0 = hudEditorManager;
        this.val$mod = modules;
        this.val$booleanValue = booleanValue;
    }
}
