// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.listener.ComponentClickListener;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.module.Modules;

public class Hud2
        implements ComponentClickListener {
    public HudEditorManager this$0;
    public Modules val$mod;

    @Override
    public void onComponenetClick(Component component, int n) {
        this.val$mod.toggle();
    }

    public Hud2(HudEditorManager hudEditorManager, Modules modules) {
        this.this$0 = hudEditorManager;
        this.val$mod = modules;
    }
}
