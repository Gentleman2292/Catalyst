// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.gui;

import com.krazzzzymonkey.catalyst.gui.click.elements.CheckButton;
import com.krazzzzymonkey.catalyst.gui.click.listener.CheckButtonClickListener;
import com.krazzzzymonkey.catalyst.managers.GuiManager;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.types.BooleanValue;

public class Gui3
        implements CheckButtonClickListener {
    public Modules val$mod;
    public GuiManager this$0;
    public BooleanValue val$booleanValue;

    @Override
    public void onCheckButtonClick(CheckButton checkButton) {
        for (Value value : this.val$mod.getValues()) {
            if (!value.getName().equals(this.val$booleanValue.getName())) continue;
            value.setValue(checkButton.isEnabled());
        }
    }

    public Gui3(GuiManager guiManager, Modules modules, BooleanValue booleanValue) {
        this.this$0 = guiManager;
        this.val$mod = modules;
        this.val$booleanValue = booleanValue;
    }
}
 