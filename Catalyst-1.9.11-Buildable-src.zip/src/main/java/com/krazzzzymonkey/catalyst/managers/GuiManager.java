/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.managers;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.base.Container;
import com.krazzzzymonkey.catalyst.gui.click.elements.*;
import com.krazzzzymonkey.catalyst.managers.gui.*;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.utils.visual.GLUtils;
import com.krazzzzymonkey.catalyst.gui.click.ClickGui;
import com.krazzzzymonkey.catalyst.value.Mode;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.sliders.DoubleValue;
import com.krazzzzymonkey.catalyst.value.sliders.IntegerValue;
import com.krazzzzymonkey.catalyst.value.types.BooleanValue;
import com.krazzzzymonkey.catalyst.value.types.ColorValue;
import com.krazzzzymonkey.catalyst.value.types.ModeValue;

public class GuiManager extends ClickGui
{
    public void Init() {
        int n = GLUtils.getFullScreenWidth();
        int n2 = 1;
        int n3 = 10;
        for (ModuleCategory moduleCategory : ModuleCategory.values()) {
            int n4 = 210;
            int n5 = 100;
            int n6 = 0;
            String string = Character.toString(moduleCategory.toString().toLowerCase().charAt(0)).toUpperCase() + moduleCategory.toString().toLowerCase().substring(1);
            Frame frame = new Frame(n2, n3, n5, n4, string);
            for (Modules modules : ModuleManager.getModules()) {
                if (modules.getCategory() != moduleCategory) continue;
                Gui1 guiManager$1 = new Gui1(this, 0, 0, n5, 14, frame, modules.getName(), modules, modules);
                guiManager$1.addListner(new Gui2(this, modules));
                guiManager$1.setEnabled(modules.isToggled());
                if (!modules.getValues().isEmpty()) {
                    for (Value value : modules.getValues()) {
                        Object object;
                        Object object2;
                        if (value instanceof BooleanValue) {
                            object2 = (BooleanValue)value;
                            object = new CheckButton(0, 0, guiManager$1.getDimension().width, 14, guiManager$1, ((Value)object2).getName(), (Boolean)((Value)object2).getValue(), null);
                            ((CheckButton)object).addListeners(new Gui3(this, modules, (BooleanValue)object2));
                            guiManager$1.addComponent((Component)object);
                            continue;
                        }
                        if (value instanceof DoubleValue) {
                            object2 = (DoubleValue)value;
                            object = new Slider(((DoubleValue)object2).getMin(), ((DoubleValue)object2).getMax(), ((DoubleValue)object2).getValue(), guiManager$1, ((Value)object2).getName());
                            ((Slider)object).addListener(new Gui4(this, modules, value));
                            guiManager$1.addComponent((Component)object);
                            continue;
                        }
                        if (value instanceof IntegerValue) {
                            object2 = (IntegerValue)value;
                            object = new Slider(((IntegerValue)object2).getMin(), ((IntegerValue)object2).getMax(), (Number)((IntegerValue)object2).getValue(), guiManager$1, ((Value)object2).getName());
                            ((Slider)object).addListener(new Gui5(this, modules, value));
                            guiManager$1.addComponent((Component)object);
                            continue;
                        }
                        if (value instanceof ModeValue) {
                            object2 = new Dropdown(0, 0, n5 - 2, 14, frame, value.getName());
                            object = (ModeValue)value;
                            for (Mode mode : ((ModeValue)object).getModes()) {
                                CheckButton checkButton = new CheckButton(0, 0, guiManager$1.getDimension().width, 14, guiManager$1, mode.getName(), mode.isToggled(), (ModeValue)object);
                                checkButton.addListeners(new Gui6(this, (ModeValue)object, mode));
                                ((Container)object2).addComponent(checkButton);
                            }
                            guiManager$1.addComponent((Component)object2);
                            continue;
                        }
                        if (!(value instanceof ColorValue)) continue;
                        object2 = (ColorValue)value;
                        object = new ColorPicker(0, 0, n5, 65, (Integer)((Value)object2).getValue(), ((ColorValue)object2).getRainbow(), guiManager$1, ((Value)object2).getName(), (ColorValue)object2);
                        ((ColorPicker)object).addListener(new Gui7(this, value));
                        guiManager$1.addComponent((Component)object);
                    }
                }
                KeybindMods keybindMods = new KeybindMods(-1, 0, 8, 14, guiManager$1, modules);
                guiManager$1.addComponent(keybindMods);
                frame.addComponent(guiManager$1);
                ++n6;
            }
            if (n2 + n5 + 10 < n) {
                n2 += n5 + 2;
            } else {
                n2 = 20;
                n3 += 60;
            }
            frame.setMaximizible(true);
            frame.setPinnable(true);
            if (moduleCategory == ModuleCategory.HUD) continue;
            this.addFrame(frame);
        }
        if (!FileManager.CLICKGUI.exists()) {
            FileManager.saveClickGui();
        } else {
            FileManager.loadClickGui();
        }
    }
}
