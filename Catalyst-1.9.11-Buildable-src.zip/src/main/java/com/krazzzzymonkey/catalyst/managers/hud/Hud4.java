// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.elements.Slider;
import com.krazzzzymonkey.catalyst.gui.click.listener.SliderChangeListener;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.value.Value;

public class Hud4
        implements SliderChangeListener {
    public Value val$value;
    public HudEditorManager this$0;
    public Modules val$mod;

    public Hud4(HudEditorManager hudEditorManager, Modules modules, Value value) {
        this.this$0 = hudEditorManager;
        this.val$mod = modules;
        this.val$value = value;
    }

    @Override
    public void onSliderChange(Slider slider) {
        for (Value value : this.val$mod.getValues()) {
            if (!value.getName().equals(this.val$value.getName())) continue;
            value.setValue(slider.getValue());
        }
    }
}
