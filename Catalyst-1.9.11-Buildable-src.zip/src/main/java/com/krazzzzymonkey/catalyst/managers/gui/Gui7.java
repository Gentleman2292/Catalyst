// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.gui;

import com.krazzzzymonkey.catalyst.gui.click.elements.ColorPicker;
import com.krazzzzymonkey.catalyst.gui.click.listener.ColorChangeListener;
import com.krazzzzymonkey.catalyst.managers.GuiManager;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.types.ColorValue;

public class Gui7
        implements ColorChangeListener {
    public GuiManager this$0;
    public Value val$value;

    @Override
    public void onColorChangeClick(ColorPicker colorPicker) {
        ((ColorValue)this.val$value).setColor(colorPicker.getColor());
    }

    public Gui7(GuiManager guiManager, Value value) {
        this.this$0 = guiManager;
        this.val$value = value;
    }
}
