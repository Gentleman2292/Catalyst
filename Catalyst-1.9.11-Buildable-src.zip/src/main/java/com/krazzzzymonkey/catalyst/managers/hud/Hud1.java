// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.hud;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.elements.ExpandingButton;
import com.krazzzzymonkey.catalyst.managers.HudEditorManager;
import com.krazzzzymonkey.catalyst.module.Modules;

public class Hud1
        extends ExpandingButton {
    public HudEditorManager this$0;
    public Modules val$mod;

    @Override
    public void onUpdate() {
        this.setEnabled(this.val$mod.isToggled());
    }

    public Hud1(HudEditorManager hudEditorManager, int n, int n2, int n3, int n4, Component component, String string, Modules modules, Modules modules2) {
        super(n, n2, n3, n4, component, string, modules);
        this.this$0 = hudEditorManager;
        this.val$mod = modules2;
    }
}
 