/**
 * Obfuscator: Binsecure,   Decompiler: Procyon
 * De-obfuscated by Gopro336 & Fixed by mrnv @ github.com/PlutoSolutions
 */
package com.krazzzzymonkey.catalyst.managers;

import com.krazzzzymonkey.catalyst.gui.click.HudEditor;
import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.base.Container;
import com.krazzzzymonkey.catalyst.gui.click.elements.CheckButton;
import com.krazzzzymonkey.catalyst.gui.click.elements.ColorPicker;
import com.krazzzzymonkey.catalyst.gui.click.elements.Dropdown;
import com.krazzzzymonkey.catalyst.gui.click.elements.Frame;
import com.krazzzzymonkey.catalyst.gui.click.elements.KeybindMods;
import com.krazzzzymonkey.catalyst.gui.click.elements.Slider;
import com.krazzzzymonkey.catalyst.managers.FileManager;
import com.krazzzzymonkey.catalyst.managers.hud.*;
import com.krazzzzymonkey.catalyst.managers.ModuleManager;
import com.krazzzzymonkey.catalyst.module.ModuleCategory;
import com.krazzzzymonkey.catalyst.module.Modules;
import com.krazzzzymonkey.catalyst.utils.visual.GLUtils;
import com.krazzzzymonkey.catalyst.value.Mode;
import com.krazzzzymonkey.catalyst.value.Value;
import com.krazzzzymonkey.catalyst.value.sliders.DoubleValue;
import com.krazzzzymonkey.catalyst.value.sliders.IntegerValue;
import com.krazzzzymonkey.catalyst.value.types.BooleanValue;
import com.krazzzzymonkey.catalyst.value.types.ColorValue;
import com.krazzzzymonkey.catalyst.value.types.ModeValue;

public class HudEditorManager extends HudEditor
{
    public void addCategoryPanels() {
        int n = GLUtils.getScreenWidth();
        int n2 = 100;
        int n3 = 20;
        ModuleCategory moduleCategory = ModuleCategory.HUD;
        int n4 = 210;
        int n5 = 100;
        int n6 = 0;
        String string = Character.toString(moduleCategory.toString().toLowerCase().charAt(0)).toUpperCase() + moduleCategory.toString().toLowerCase().substring(1);
        Frame frame = new Frame(n2, n3, n5, n4, string);
        for (Modules modules : ModuleManager.getModules()) {
            if (modules.getCategory() != moduleCategory) continue;
            Hud1 hudEditorManager$1 = new Hud1(this, 0, 0, n5, 14, frame, modules.getName(), modules, modules);
            hudEditorManager$1.addListner(new Hud2(this, modules));
            hudEditorManager$1.setEnabled(modules.isToggled());
            if (!modules.getValues().isEmpty()) {
                for (Value value : modules.getValues()) {
                    Object object;
                    Object object2;
                    if (value instanceof BooleanValue) {
                        object2 = (BooleanValue)value;
                        object = new CheckButton(0, 0, hudEditorManager$1.getDimension().width, 14, hudEditorManager$1, ((Value)object2).getName(), (Boolean)((Value)object2).getValue(), null);
                        ((CheckButton)object).addListeners(new Hud3(this, modules, (BooleanValue)object2));
                        hudEditorManager$1.addComponent((Component)object);
                        continue;
                    }
                    if (value instanceof DoubleValue) {
                        object2 = (DoubleValue)value;
                        object = new Slider(((DoubleValue)object2).getMin(), ((DoubleValue)object2).getMax(), ((DoubleValue)object2).getValue(), hudEditorManager$1, ((Value)object2).getName());
                        ((Slider)object).addListener(new Hud4(this, modules, value));
                        hudEditorManager$1.addComponent((Component)object);
                        continue;
                    }
                    if (value instanceof IntegerValue) {
                        object2 = (IntegerValue)value;
                        object = new Slider(((IntegerValue)object2).getMin(), ((IntegerValue)object2).getMax(), (Number)((IntegerValue)object2).getValue(), hudEditorManager$1, ((Value)object2).getName());
                        ((Slider)object).addListener(new Hud5(this, modules, value));
                        hudEditorManager$1.addComponent((Component)object);
                        continue;
                    }
                    if (value instanceof ModeValue) {
                        int n7 = n5;
                        object2 = new Dropdown(0, 0, (n7 & ~2) + (2 & ~n7), 14, frame, value.getName());
                        object = (ModeValue)value;
                        for (Mode mode : ((ModeValue)object).getModes()) {
                            CheckButton checkButton = new CheckButton(0, 0, hudEditorManager$1.getDimension().width, 14, hudEditorManager$1, mode.getName(), mode.isToggled(), (ModeValue)object);
                            checkButton.addListeners(new Hud6(this, (ModeValue)object, mode));
                            ((Container)object2).addComponent(checkButton);
                        }
                        hudEditorManager$1.addComponent((Component)object2);
                        continue;
                    }
                    if (!(value instanceof ColorValue)) continue;
                    object2 = (ColorValue)value;
                    object = new ColorPicker(0, 0, n5, 65, (Integer)((Value)object2).getValue(), ((ColorValue)object2).getRainbow(), hudEditorManager$1, ((Value)object2).getName(), (ColorValue)object2);
                    ((ColorPicker)object).addListener(new Hud7(this, value));
                    hudEditorManager$1.addComponent((Component)object);
                }
            }
            KeybindMods keybindMods = new KeybindMods(-1, 0, 8, 14, hudEditorManager$1, modules);
            hudEditorManager$1.addComponent(keybindMods);
            frame.addComponent(hudEditorManager$1);
            ++n6;
        }
        frame.setMaximizible(true);
        frame.setPinnable(true);
        frame.setMaximized(true);
        this.addFrame(frame);
        frame.updateComponents();
        if (!FileManager.CLICKGUI.exists()) {
            FileManager.saveClickGui();
        } else {
            FileManager.loadClickGui();
        }
    }
    
    public void Initialization() {
        this.addCategoryPanels();
    }
}
