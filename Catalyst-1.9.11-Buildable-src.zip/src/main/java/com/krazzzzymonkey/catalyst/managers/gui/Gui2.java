// Decompiled with: CFR 0.152
// Class Version: 8
// ERROR: Unable to apply inner class name fixup
package com.krazzzzymonkey.catalyst.managers.gui;

import com.krazzzzymonkey.catalyst.gui.click.base.Component;
import com.krazzzzymonkey.catalyst.gui.click.listener.ComponentClickListener;
import com.krazzzzymonkey.catalyst.managers.GuiManager;
import com.krazzzzymonkey.catalyst.module.Modules;

public class Gui2
        implements ComponentClickListener {
    public Modules val$mod;
    public GuiManager this$0;

    @Override
    public void onComponenetClick(Component component, int n) {
        this.val$mod.toggle();
    }

    public Gui2(GuiManager guiManager, Modules modules) {
        this.this$0 = guiManager;
        this.val$mod = modules;
    }
}
 