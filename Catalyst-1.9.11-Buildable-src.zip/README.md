# Catalist-Deobf
 Catalist client deobfuscated by Gopro336 & perry. <br>
 Very weak Binscure config lol. <br>
 Decompiled with procyon. <br>
 Credits to Crystallinqq for the jar file. <br>